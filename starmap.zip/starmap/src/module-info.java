/**
 * 
 */
/**
 * 
 */
module starmap {
	requires java.sql;
	requires java.desktop;
}